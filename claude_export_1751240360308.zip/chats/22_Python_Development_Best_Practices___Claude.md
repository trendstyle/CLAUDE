# Python Development Best Practices - Claude

## User
each programming language for softrware development has critical pitfalls and caveats to be actively planned for and circumvented during planning and the development cycle, many of which are simple like poor syntax, or overly long files, or not seperating of components into manageable files that are seperated for into for example 1 file per function. which makes loading speed optimal and problem isolation quick to identify, or badly implemented /non existent debugging tools that should have been deeply baked into the development process from the very start. 
with this in mind find me the top 100 rules to ensure smooth and trouble free development cycle and that actively promote and enforce the implementing of known best practise and futureproofing/backwards compatibilty , when programming in python  search the web to truly understand and cast a wide yet detailed catch all net to find these rules that mitigate every bad practise that has happened and possibly still happens today

## Claude
Strategized comprehensive Python development rules via extensive web research.

5s

The user is asking for the top 100 rules to ensure smooth Python development. This is a fairly clear request - they want comprehensive best practices for Python development, covering everything from syntax to architecture to debugging. They specifically mention:

Finding pitfalls and caveats in Python
Rules that enforce best practices
Future-proofing and backwards compatibility
Proper file organization (one function per file, etc.)
Debugging tools integration
They want me to search the web for comprehensive information

This is a detailed enough request that I don't need clarifying questions. The user has been specific about wanting:

Top 100 rules (comprehensive list)
Python-specific
Focus on preventing problems
Include development cycle best practices
Cover known bad practices to avoid

I should launch the extended search task immediately to gather comprehensive information about Python development best practices.

I understand you're looking for a comprehensive set of rules to ensure smooth Python development that covers everything from basic syntax pitfalls to advanced architectural patterns. This is an excellent approach to establishing a solid foundation for your development practices.

Let me dive into extensive research to gather the most comprehensive and up-to-date Python development best practices from across the web. I'll look for rules that address common pitfalls, enforce established best practices, and help with future-proofing your code.

Your Python development best practices guide is ready. It covers 100 comprehensive rules across core syntax, code organization, performance optimization, testing methods, code quality standards, security practices, and development workflows. The guide provides practical examples and explanations for writing robust, maintainable, performant, secure, and Pythonic code.

Top 100 Comprehensive Rules for Smooth Python Development
Document 
# Top 100 Comprehensive Rules for Smooth Python Development

## Core Syntax and Common Pitfalls (1-15)

**1. Always use colons for compound statements**
Compound statements (if, for, while, def, class) require colons. This is the most common beginner

