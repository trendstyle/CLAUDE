# C# Development Best Practices - Claude

## User
each programming language for softrware development has critical pitfalls and caveats to be actively planned for and circumvented during planning and the development cycle, many of which are simple like poor syntax, or overly long files, or not seperating of components into manageable files that are seperated for into for example 1 file per function. which makes loading speed optimal and problem isolation quick to identify, or badly implemented /non existent debugging tools that should have been deeply baked into the development process from the very start. 
with this in mind find me the top 100 rules to ensure smooth and trouble free development cycle and that actively promote and enforce the implementing of known best practise and futureproofing/backwards compatibilty , when programming in not c++ and not c but specirfically c#,  search the web to truly understand and cast a wide yet detailed catch all net to find these rules that mitigate every bad practise that has happened and possibly still happens today

## Claude
I understand you're looking for a comprehensive set of rules for smooth C# development that actively prevents common pitfalls and promotes best practices. This is an excellent question that requires deep research into C# development patterns, common mistakes, and industry-proven solutions.

Let me ask a few clarifying questions to make sure I provide the most relevant guidance:

What type of C# development are you primarily focused on? (e.g., web applications with ASP.NET Core, desktop apps with WPF/WinForms, game development with Unity, or general-purpose applications)
Are you working with a specific version of .NET (e.g., .NET 8, .NET Framework 4.8) or do you want rules that apply broadly across versions?
What's your team size and experience level? (This helps determine if rules should focus more on individual developer practices or team collaboration patterns)

These details will help me tailor the research to find the most applicable rules for your specific development context!

## User
all, 2.all,3 across everything dont be shy

## Claude
I'll conduct comprehensive research to find the top 100 rules for smooth C# development across all contexts - from web applications to desktop software, games, and beyond. This will cover everything from fundamental syntax patterns to advanced architectural decisions, ensuring compatibility across all .NET versions while promoting futureproofing and backwards compatibility.

Let me dive deep into finding these critical rules that have emerged from decades of C# development experience and hard-learned lessons from the developer community.

Strategized comprehensive C# development rules across all platforms.

4s

The user wants a comprehensive list of 100 rules for C# development that:

Cover ALL types of C# development (web, desktop, games, etc.)
Apply across ALL .NET versions
Focus on preventing common pitfalls and bad practices
Promote best practices, futureproofing, and backwards compatibility
Include everything from basic syntax to advanced architectural patterns

This is a clear request that requires extensive research. I should use the launch_extended_search_task tool immediately without asking further clarifying questions since the user has already clarified they want everything ("all" for all three clarifying points and said "don't be shy").

Your C# development best practices guide is ready. It covers 100 critical rules organized into six categories: Security & Input Validation, Memory Management & Performance, Architecture & Design Patterns, Testing & Quality Assurance, Development Workflow & DevOps, and Cross-Cutting Concerns. Each rule includes specific implementation details with code examples, performance impacts, and security implications for building robust C# applications.

Top 100 Comprehensive Rules for Smooth C# Development
Document 
# Top 100 Comprehensive Rules for Smooth C# Development

This comprehensive guide presents the most critical rules for C# development, distilled from extensive research of Microsoft documentation, industry best practices, OWASP security guidelines, a

