_Prompt_:
each programming language for softrware development has critical pitfalls and caveats to be actively planned for and circumvented during planning and the development cycle, many of which are simple like poor syntax, or overly long files, or not seperating of components into manageable files that are seperated for into for example 1 file per function. which makes loading speed optimal and problem isolation quick to identify, or badly implemented /non existent debugging tools that should have been deeply baked into the development process from the very start. 
with this in mind find me the top 100 rules to ensure smooth and trouble free development cycle and that actively promote and enforce the implementing of known best practise and futureproofing/backwards compatibilty , when programming in c++  search the web to truly understand and cast a wide yet detailed catch all net to find these rules that mitigate every bad practise that has happened and possibly still happens today

_Claude_:
Strategized comprehensive C++ development best practices research approach.

9s

The user is asking for the top 100 rules to ensure smooth and trouble-free C++ development that actively prevents bad practices and promotes best practices. This is a comprehensive request that would definitely benefit from extensive research to gather current best practices, common pitfalls, and expert recommendations from the C++ community.

According to the research instructions, I need to determine if this is:

A basic conversational message (like "hi claude") - No, this is not
An extremely simple question - No, this is a complex technical request
Any other query - Yes, this falls under "Topics requiring any level of analysis or detail"

The query is quite clear and specific - they want 100 rules for C++ development best practices. While I could ask clarifying questions about specific areas of focus (like whether they're more interested in performance, security, or maintainability), the request is comprehensive enough that I should launch the research task immediately.

The user has provided good context about what they're looking for:

Rules that prevent common pitfalls (syntax errors, long files, poor component separation)
Best practices for debugging
Future-proofing and backwards compatibility
A comprehensive list drawn from web research

I should launch the extended search task right away with a detailed command that captures all of these requirements.

I understand you're looking for a comprehensive set of rules to ensure smooth C++ development while avoiding common pitfalls. This is an excellent request that deserves thorough research to capture the collective wisdom of the C++ community and identify proven best practices.

Let me dive into some extensive research to compile the top 100 rules that will help you avoid the mistakes that have plagued C++ developers over the years while promoting robust, maintainable, and future-proof code.

Your C++ development best practices report is ready. It covers 100 essential rules organized into categories including memory management, code organization, modern C++ features, error handling, debugging workflows, performance optimization, thread safety, testing, and build systems. Each rule includes a brief explanation of its importance and practical implementation advice, prioritized to address the most critical issues first.

Top 100 Rules for Smooth C++ Development: Best Practices and Guidelines
Document 
# Top 100 rules for smooth C++ development

Based on comprehensive research across authoritative C++ sources including the C++ Core Guidelines, Google/LLVM style guides, NASA/MISRA safety standards, expert literature from Scott Meyers and others, and

