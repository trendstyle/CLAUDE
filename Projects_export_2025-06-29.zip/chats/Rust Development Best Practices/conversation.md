_Prompt_:
each programming language for softrware development has critical pitfalls and caveats to be actively planned for and circumvented during planning and the development cycle, many of which are simple like poor syntax, or overly long files, or not seperating of components into manageable files that are seperated for into for example 1 file per function. which makes loading speed optimal and problem isolation quick to identify, or badly implemented /non existent debugging tools that should have been deeply baked into the development process from the very start. 
with this in mind find me the top 100 rules to ensure smooth and trouble free development cycle and that actively promote and enforce the implementing of known best practise and futureproofing/backwards compatibilty , when programming in rust  search the web to truly understand and cast a wide yet detailed catch all net to find these rules that mitigate every bad practise that has happened and possibly still happens today

_Claude_:
Strategized comprehensive web search for Rust development best practices.

4s

The user is asking for a comprehensive list of the top 100 rules for smooth and trouble-free development in Rust, with a focus on best practices, future-proofing, and avoiding common pitfalls. They want me to search the web to find detailed information about these rules.

Let me analyze this request:

The query is clear and specific - they want 100 rules for Rust development
They've provided context about what they're looking for (avoiding pitfalls, implementing best practices, future-proofing)
They explicitly ask me to search the web for this information

Since this is a clear request that would benefit from comprehensive research across multiple sources, I should use the launch_extended_search_task tool immediately without asking clarifying questions. The user has been quite specific about what they want.

I'll launch the research task with a detailed command that captures all their requirements.

I understand you're looking for a comprehensive guide to ensure smooth Rust development by avoiding common pitfalls and implementing best practices. This is an excellent approach to mastering Rust, as the language has unique ownership rules and patterns that can trip up developers coming from other languages.

Let me dive into extensive research to find the top 100 rules that cover everything from syntax best practices to architectural decisions, debugging strategies, and future-proofing techniques. I'll search for insights from the Rust community, official documentation, and experienced developers to create a thorough guide.

Rust development best practices

Research complete
•
489 sources
•
10m 11s

Your Rust development best practices guide is ready. It covers 100 essential rules organized into seven categories: memory safety and ownership, code organization, error handling, syntax and type system, performance optimization, testing and documentation, concurrency and async patterns, build system management, and security considerations. The guide provides practical advice for avoiding common pitfalls and writing robust Rust code.

Top 100 Rules for Smooth and Trouble-Free Rust Development
Document 
# Top 100 Rules for Smooth and Trouble-Free Rust Development

## Memory Safety and Ownership (15 Rules)

**1. Prefer owned data over reference-heavy structs**
When designing APIs, use `String` instead of `&str` and `Vec<T>` instead of `&[T]` in struc

