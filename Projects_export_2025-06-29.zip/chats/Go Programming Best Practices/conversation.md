_Prompt_:
each programming language for softrware development has critical pitfalls and caveats to be actively planned for and circumvented during planning and the development cycle, many of which are simple like poor syntax, or overly long files, or not seperating of components into manageable files that are seperated for into for example 1 file per function. which makes loading speed optimal and problem isolation quick to identify, or badly implemented /non existent debugging tools that should have been deeply baked into the development process from the very start. 
with this in mind find me the top 100 rules to ensure smooth and trouble free development cycle and that actively promote and enforce the implementing of known best practise and futureproofing/backwards compatibilty , when programming in go,  search the web to truly understand and cast a wide yet detailed catch all net to find these rules that mitigate every bad practise that has happened and possibly still happens today

_Claude_:
Strategized comprehensive Go development rules via extensive web research.

6s

The user is asking for the top 100 rules to ensure smooth and trouble-free development in Go programming, with a focus on avoiding pitfalls, implementing best practices, and ensuring futureproofing and backwards compatibility. This is a comprehensive request that would benefit from extensive research.

Looking at the research instructions, this falls under the category of "Any request for information" and "Topics requiring any level of analysis or detail." It's not a basic conversational message or an extremely simple question.

The query is fairly clear - they want:

Top 100 rules for Go development
Focus on avoiding common pitfalls and bad practices
Emphasis on best practices
Futureproofing and backwards compatibility considerations
Rules that promote smooth development cycles

I should use the launch_extended_search_task tool immediately as the request is clear and detailed enough. No clarifying questions are needed.

I understand you're looking for a comprehensive guide to Go development best practices that will help avoid common pitfalls and ensure smooth, maintainable code. This is an excellent request that deserves thorough research to capture the full breadth of Go-specific challenges and solutions.

Let me dive deep into researching the top 100 rules for Go development, covering everything from syntax pitfalls to architectural best practices, debugging strategies, and future-proofing techniques.

Go development best practices

Research complete
•
494 sources
•
8m 42s

Your Go development best practices guide is ready. It includes 100 critical rules across concurrency, error handling, performance optimization, code organization, and memory management. The guide covers common pitfalls, debugging techniques, interface design, and package management strategies based on production experience from companies like Google, Uber, and Cloudflare.

Top 100 Rules for Smooth and Trouble-Free Go Development
Document 
# Top 100 Rules for Smooth and Trouble-Free Go Development

This comprehensive guide presents the 100 most critical rules for Go programming, compiled from official documentation, industry experts, and production experience at companies like Google, 

