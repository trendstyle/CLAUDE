_Prompt_:
each programming language for softrware development has critical pitfalls and caveats to be actively planned for and circumvented during planning and the development cycle, many of which are simple like poor syntax, or overly long files, or not seperating of components into manageable files that are seperated for into for example 1 file per function. which makes loading speed optimal and problem isolation quick to identify, or badly implemented /non existent debugging tools that should have been deeply baked into the development process from the very start. with this in mind find me the top 100 rules to ensure smooth and trouble free development cycle and that actively promote and enforce the implementing of known best practise and futureproofing/backwards compatibilty , givin this research and identify the key top 100 rules to implement for cross os development to ensure smooth development and serves to mitigate known issues from causing big headaches for development teams down the line, search the web to truly understand and cast a wide yet detailed catch all net to find these rules that mitigate every bad practise that has happened and possibly still happens today

_Claude_:
I understand you're looking for a comprehensive set of development rules that would help teams avoid common pitfalls and ensure smooth cross-platform development cycles. This is a crucial topic since poor development practices can compound into major technical debt and project delays.

Before I dive into researching these top 100 rules, let me clarify a few things to ensure I provide the most relevant and actionable guidance:

Development scope: Are you primarily interested in rules for application development (web, mobile, desktop), system-level programming, or both? Different domains have different critical pain points.
Team size & structure: Are these rules intended for solo developers, small teams (2-10 people), or larger enterprise teams? Team dynamics significantly affect which practices are most critical.
Technology stack preference: While you want cross-platform rules, do you have any particular languages or frameworks in mind (e.g., JavaScript/TypeScript, Python, Java, C++)? Some rules are universal, but others are language-specific.

Once I understand these aspects better, I'll conduct thorough research to compile the most comprehensive and practical set of development rules that address everything from code organization and debugging strategies to future-proofing and cross-platform compatibility concerns.

_Prompt_:
cross platform so its a catch all approach for your list get get it all for every device type and associated os and archetecture.
it shouldnt matter, because if followed by any size team they will have the same effect
both esapecially critical language specific rules should be categorized by their languages

_Claude_:
Excellent! You're looking for a truly comprehensive catch-all approach that covers every development scenario. This is exactly the kind of systematic thinking that prevents those frustrating "if only we had thought of this earlier" moments that plague so many projects.

Let me dive into extensive research to compile these 100 critical rules. I'll search across multiple sources including:

Post-mortems from major software failures
Best practices documentation from tech giants
Cross-platform development frameworks' official guidelines
Language-specific style guides and pitfall compilations
DevOps and CI/CD best practices
Security vulnerability databases and their root causes
Performance optimization guides across different architectures

I'll organize the rules into clear categories and highlight which are universal versus language/platform-specific, ensuring each rule directly addresses a real problem that teams have encountered.

Cross-platform development rules

Research complete
•
826 sources
•
13m 51s

Your cross-platform software development guide is ready. It contains 100 critical rules organized into categories including development process, error handling, performance optimization, security, version control, testing, CI/CD, and monitoring. Each rule includes the specific problem it prevents and clear implementation guidance. The report covers both universal principles and language/platform-specific best practices derived from real production failures.

Top 100 Critical Development Rules for Cross-Platform Software Development
Document 
# Top 100 Critical Development Rules for Cross-Platform Software Development

## Development Process & Architecture (Universal Rules 1-15)

### 1. Start Small, Then Extend
**Problem Prevented**: Complex system failures like Heathrow Terminal 5's bagg

