_Prompt_:
each programming language for softrware development has critical pitfalls and caveats to be actively planned for and circumvented during planning and the development cycle, many of which are simple like poor syntax, or overly long files, or not seperating of components into manageable files that are seperated for into for example 1 file per function. which makes loading speed optimal and problem isolation quick to identify, or badly implemented /non existent debugging tools that should have been deeply baked into the development process from the very start. 
with this in mind find me the top 100 rules to ensure smooth and trouble free development cycle and that actively promote and enforce the implementing of known best practise and futureproofing/backwards compatibilty , when programming in javascript search the web to truly understand and cast a wide yet detailed catch all net to find these rules that mitigate every bad practise that has happened and possibly still happens today

_Claude_:
Strategized comprehensive research on JavaScript development best practices.

4s

The user is asking for the top 100 rules to ensure smooth JavaScript development, with a focus on best practices, avoiding pitfalls, and ensuring futureproofing/backwards compatibility. They want me to search the web to find comprehensive rules that mitigate bad practices.

This is a clear request for comprehensive research on JavaScript best practices. According to the research instructions, this is definitely a case where I should use the launch_extended_search_task tool. The user has been quite specific about what they want - a comprehensive list of 100 rules for JavaScript development that covers:

Critical pitfalls and caveats
Best practices
Futureproofing and backwards compatibility
Proper file organization
Debugging tools implementation
Syntax issues
Component separation
Loading speed optimization
Problem isolation

The query is detailed enough that I don't need to ask clarifying questions. I should launch the research task immediately.

I'll dive deep into researching the most comprehensive JavaScript development rules and best practices for you. This will cover everything from avoiding critical pitfalls to implementing proper debugging strategies and ensuring future-proof, maintainable code.

JavaScript development rules

Research complete
•
535 sources
•
7m 3s

Here's your comprehensive JavaScript development best practices guide. It covers 100 essential rules organized into six key areas: fundamental JavaScript pitfalls, modern syntax features, code organization, performance optimization, testing/quality assurance, and security/deployment practices. Each rule includes a practical explanation to help you write more robust, maintainable JavaScript code.

Top 100 Rules for Smooth JavaScript Development
Document 
# Top 100 rules for smooth JavaScript development

## Fundamental JavaScript Pitfalls and Type Safety (Rules 1-15)

**1. Always use strict equality (===) over loose equality (==)**  
Loose equality performs type coercion leading to bugs like `'0' == 

